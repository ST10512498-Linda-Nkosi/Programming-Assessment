/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.icetask2;

import java.util.Scanner;

/**
 *
 * @author docto
 */
public class IceTask2 {

    public static void main(String[] args) {
          Scanner input=new Scanner(System.in);
        System.out.print("Enter a name :");
        String name=input.next();
        System.out.print("Enter a surname :");
        String surname=input.next();
        System.out.print("Enter a age :");
        int age=input.nextInt();
        boolean check=CheckIdentity(name,surname,age);
        if(check==true){
            System.out.println("It is Jack");
        }else{
            System.out.println("This is not Jack");
        }
    }
    public static boolean CheckIdentity(String name,String surname,int age){
        if(name.equalsIgnoreCase("Jack")&& surname.equalsIgnoreCase("Khoza")&& age==25){
            return true;
        }else{
        return false;
    }
    } 
}

    

